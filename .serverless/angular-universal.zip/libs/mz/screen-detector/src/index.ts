export * from './lib/mz-screen-detector.module';
