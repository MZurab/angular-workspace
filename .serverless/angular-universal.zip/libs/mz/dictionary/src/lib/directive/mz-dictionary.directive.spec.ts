import { MzDictionaryDirective } from './mz-dictionary.directive';

describe('MzDictionaryDirective', () => {
  it('should create an instance', () => {
    // const directive = new MzDictionaryDirective();
    // expect(directive).toBeTruthy();
  });
});
