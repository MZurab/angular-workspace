import {MzDictionaryAbstractClass} from "../@abstract/@class/mz-dictionary.abstract.class";

export class MzDictionaryDefaultClass extends MzDictionaryAbstractClass{

}
