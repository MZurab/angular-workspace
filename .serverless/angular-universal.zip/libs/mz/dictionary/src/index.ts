export * from './lib/mz-dictionary.module';
