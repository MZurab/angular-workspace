export * from './lib/connect-app-controller.module';
