export enum AngularAppIdEnum {
  web = 'web',
  embedChat = 'embed-chat-agent'
}
