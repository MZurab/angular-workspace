export enum AppsIdEnum {
  chat = 'chat',
  edocument = 'edocument',
  sharepay = 'sharepay',
  onepay = 'onepay',
  market = 'market'
}
