export enum UserStateEnum {
  //  1 - notComfirmed
  notComfirmed = 0,
  //  1 - confirmedBySms
  confirmedBySms = 1
}
