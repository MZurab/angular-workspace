// import { ConnectApps } from '../connect-app-controller.inerface';

export interface ConnectAppControllerState {
  // apps: ConnectApps;
  // list: Entity[]; // list of ConnectAppController; analogous to a sql normalized table
  // selectedId?: string | number; // which ConnectAppController record has been selected
  // loaded: boolean; // has the ConnectAppController list been loaded
  // error?: any; // last none error (if any)
}
