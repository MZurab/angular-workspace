import { Component } from '@angular/core';

@Component({
  selector: 'mz-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'connect-built-in-site';
}
