import {connectAppControllerReducer} from "../../../../../libs/connect/app-controller/src/lib/+state/connect-app-controller.reducer";

export const reducers = {
 'connect' : connectAppControllerReducer
};
