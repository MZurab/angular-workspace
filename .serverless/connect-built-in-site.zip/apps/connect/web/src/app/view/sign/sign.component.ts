import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'connect-web-base-sign',
  templateUrl: './sign.component.html',
  styleUrls: ['./sign.component.scss']
})
export class SignComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
