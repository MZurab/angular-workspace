// import { async, TestBed } from '@angular/core/testing';
// import { ConnectAppControllerModule } from './connect-app-controller.module';
//
// describe('ConnectAppControllerModule', () => {
//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       imports: [ConnectAppControllerModule]
//     }).compileComponents();
//   }));
//
//   it('should create', () => {
//     expect(ConnectAppControllerModule).toBeDefined();
//   });
// });
