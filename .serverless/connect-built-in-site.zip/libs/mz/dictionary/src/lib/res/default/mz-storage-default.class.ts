import {MzStorageAbstractClass} from "../@abstract/@class/mz-storage.abstract.class";

export class MzStorageDefaultClass extends MzStorageAbstractClass{

}
