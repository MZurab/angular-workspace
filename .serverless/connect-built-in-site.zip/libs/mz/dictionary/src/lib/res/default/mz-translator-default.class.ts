import {MzTranslatorAbstractClass} from "../@abstract/@class/mz-translator.abstract.class";

export class MzTranslatorDefaultClass extends MzTranslatorAbstractClass {

}
