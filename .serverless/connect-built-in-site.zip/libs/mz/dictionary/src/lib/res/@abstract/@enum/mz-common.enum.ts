export enum MzLanguageEnum {
  ru = 'ru',
  en = 'en'
}
export enum MzDictionaryInputTypeEnum {
  http = 'http',
  graphQl = 'graphql'
}

export enum MzDictionaryNeedTypeEnum {
  dictionary = 'dictionary',
  hash = 'hash'
}

