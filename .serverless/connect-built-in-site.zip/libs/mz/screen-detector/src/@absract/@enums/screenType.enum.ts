export enum ScreenTypeEnum {
  small = 'small',
  medium = 'medium',
  large = 'large'
}
