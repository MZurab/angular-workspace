export interface IConfig {
  medium: number;
  large: number;
}
export type ScreenDetectorAnswer = {
  type: string;
  width: number;
  height: number;
};
